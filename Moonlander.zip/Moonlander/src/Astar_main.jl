########################
##  A* main function  ##
########################

include("Types.jl")
include("isValid.jl")
include("tracePath.jl")
include("movementCost.jl")
include("calculate_hValue.jl")
include("tracePath.jl")

function AStar(grid, src, dest)
    if !isValid(src[1],src[2]) || !isValid(dest[1],dest[2])
        print("Invalid source/destination.")
        return []
    end

    cellDetails = [Cell() for _ in 1:ROW, _ in 1:COL]
    closedList = falses(ROW,COL)
    i, j = src
    cellDetails[i,j].f = 0
    cellDetails[i,j].g = 0
    cellDetails[i,j].h = 0
    cellDetails[i,j].parent_i = i
    cellDetails[i,j].parent_j = j

    openList = PriorityQueue{Tuple{Int, Int}, Float64}()
    push!(openList, (i,j) => 0)

    directions = [(0, 1), (0, -1), (1, 0), (-1, 0), (1,1), (1,-1), (-1,1), (-1,-1)]

    while !isempty(openList)
        (i,j) = dequeue!(openList)
        closedList[i,j] = true

        for (di, dj) in directions
            ni, nj = i + di, j + dj
            if isValid(ni,nj) && !closedList[ni,nj]
                gNew = cellDetails[i,j].g + movementCost(grid, i, j, ni, nj)
                hNew = calculate_hValue(ni,nj,dest)
                fNew = gNew + hNew

                if cellDetails[ni, nj].f == Inf || cellDetails[ni,nj].f > fNew
                    push!(openList, (ni,nj) => fNew)
                    cellDetails[ni,nj].f = fNew
                    cellDetails[ni,nj].g = gNew
                    cellDetails[ni,nj].h = hNew
                    cellDetails[ni,nj].parent_i = i
                    cellDetails[ni,nj].parent_j = j
                end

                if (ni,nj) == dest
                    return tracePath(cellDetails, dest)
                end
            end
        end
    end
    return []
end
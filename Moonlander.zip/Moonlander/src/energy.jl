#######################
##  function Energy  ##
#######################

function energy(tour::Tour)
    total = 0.0
    for (k, c1) in enumerate(tour.order)
        c2 = tour.order[mod1(k + 1, length(tour.order))]
        total += tour.D[c1, c2]
    end
    return total
end
#############
##  Types  ##
#############

struct TerrainCell
    height::Int
    surface::Symbol
end

mutable struct Cell
    parent_i::Int
    parent_j::Int
    f::Float64
    g::Float64
    h::Float64
    Cell() = new(0, 0, Inf, Inf, 0)
end

struct Tour
    order::Vector{Int}
    D::Matrix{Float64}
end

Tour(D::Matrix) = Tour(tsp_order, D);
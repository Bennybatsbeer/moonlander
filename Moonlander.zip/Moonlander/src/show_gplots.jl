###############################
##  plot nodes Christofides  ##
###############################

function show_gplots(p1, p2, p3)
    Compose.table(1, 3, [p1 p2 p3])
end
###############
##  isValid  ##
###############

function isValid(row, col)
    return row ≥ 1 && row ≤ ROW && col ≥ 1 && col ≤ COL
end
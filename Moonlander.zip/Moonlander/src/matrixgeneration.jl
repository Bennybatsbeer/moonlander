const dim = 500
const row = dim
const col = dim

function addCircularFeature(heightmap, center_i, center_j, radius, depth)
    for i in max(1, center_i - radius):min(ROW, center_i + radius)
        for j in max(1, center_j - radius):min(COL, center_j + radius)
            dist = sqrt((i - center_i)^2 + (j - center_j)^2)
            if dist <= radius
                effect = round(Int, depth * cos((π/2) * (dist / radius)))
                heightmap[i,j] -= effect
            end
        end
    end
end

function exportStaticHeightmap(rows, cols, filename)
    if dim == 100
        heightmap = fill(20, rows, cols)
        for _ in 1:120
            addCircularFeature(heightmap, rand(10:(rows-2)), rand(10:cols-2), rand(3:10), rand(5:10))
        end
        heightmap .= round.(Int, 60 .* (heightmap .- minimum(heightmap)) ./ (maximum(heightmap) - minimum(heightmap)))
        open(filename, "w") do io
            println(io, "const HEIGHTMAP_$(rows) = [")
            for i in 1:rows
                println(io, "    ", join(heightmap[i, :], " "), i < rows ? ";" : "")
            end
            println(io, "]")
        end
    else
        heightmap = fill(300, rows, cols)

        feature_count = round(Int, 0.12 * rows * cols / 100)

        for _ in 1:feature_count
            radius = rand(5:60)
            depth = rand(radius/3:radius/2)
            margin = radius + 5
            center_i = rand(margin:(rows - margin))
            center_j = rand(margin:(cols - margin))
            addCircularFeature(heightmap, center_i, center_j, radius, depth)
        end

    heightmap .= round.(Int, 60 .* (heightmap .- minimum(heightmap)) ./ (maximum(heightmap) - minimum(heightmap)))
        open(filename, "w") do io
            println(io, "const HEIGHTMAP_$(rows) = [")
            for i in 1:rows
                println(io, "    ", join(heightmap[i, :], " "), i < rows ? ";" : "")
            end
            println(io, "]")
        end
    end
end

exportStaticHeightmap(row, col, "heightmap100.jl")
exportStaticHeightmap(row, col, "heightmap500.jl")

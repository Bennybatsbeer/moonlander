#################################
##  plot the Path local search ##
#################################

function plotSimulatedAnnealingTour(grid, checkpoints, best_tour)
    full_path = path_from_order(best_tour.order, checkpoints, grid)
    print("\n\nSimulated Annealing Tour Order: ", best_tour.order)
    print("\nSimulated Annealing Total Cost: ", round(energy(best_tour), digits=2))
    plotMoonSurface(grid, full_path; waypoints=checkpoints)
end
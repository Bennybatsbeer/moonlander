################################
##  function local candidate  ##
################################

function propose_candidate(tour::Tour)
    n = length(tour.order)
    order = copy(tour.order)
	
    # Order will be reversed between i1 and i2 included
    i1 = rand(1:n)
    i2 = mod1(rand(1:n-1) + i1, n)  # Make sure i1 != i2
	    
    # Make sure that i1 < i2
    if i1 > i2
        i1, i2 = i2, i1
    end
	
    if i1 == 1 && i2 == n
        return Tour(order, tour.D), 0.0
    end
	
    city_a1 = order[i1]
    city_a2 = order[i2]
	
    city_b1 = order[mod1(i1 - 1, n)]  # Index following i1
    city_b2 = order[mod1(i2 + 1, n)]  # Index preceding i2
	
	
    dE = (tour.D[city_a1, city_b2] + tour.D[city_a2, city_b1] - tour.D[city_a1, city_b1] - tour.D[city_a2, city_b2])

    order[i1:i2] = reverse(order[i1:i2])
        
    dE = energy(Tour(order, tour.D)) - energy(tour)

    return Tour(order, tour.D), dE
end
#################################
##  make the Path Christofides ##
#################################

function tracePath(cellDetails, dest)
    path = []
    row, col = dest
    while !(cellDetails[row, col].parent_i == row && cellDetails[row, col].parent_j == col)
        push!(path, (row, col))
        row, col = cellDetails[row, col].parent_i, cellDetails[row, col].parent_j
    end
    push!(path, (row, col))
    reverse!(path)
    return path
end
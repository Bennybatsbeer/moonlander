##################################
##  run Simulated Annealing TSP ##
##################################

function runSimulatedAnnealingTSP(grid, checkpoints)
    D = CostMatrix
	n = size(D,1)

    samples = [Tour(D) for _ in 1:1000]
    prob = AnnealingOptimization(energy, propose_candidate, samples, n*(n-1))
    best_tour, tour_length = simulated_annealing(prob)
    return best_tour, tour_length
end
############################
##  Install Dependencies  ##
############################

using Pkg
Pkg.add.(["DataStructures", "Plots", "Random", "Statistics", "Graphs", "SimpleWeightedGraphs", "Multigraphs", "GraphPlot", "Compose", "SimulatedAnnealing", "Cairo"])

#######################
##  get moonsurface  ##
#######################

include("Types.jl")

function moonSurface_from_matrix(heightmap::Matrix{Int})
    rows, cols = size(heightmap)
    min_h, max_h = minimum(heightmap), maximum(heightmap)
    heightmap .= round.(Int, 60 * (heightmap .- min_h) ./ (max_h - min_h))

    grid = Array{TerrainCell}(undef, rows, cols)

    for i in 1:rows, j in 1:cols
        h = heightmap[i, j]
        neighbors = Float64[]
        for di in -1:1, dj in -1:1
            ni, nj = i + di, j + dj
            if ni in 1:rows && nj in 1:cols && !(di == 0 && dj == 0)
                push!(neighbors, abs(heightmap[ni, nj] - h))
            end
        end
        slope = isempty(neighbors) ? 0.0 : mean(neighbors)
        surface = if slope > 10 || h > 50
            :dust
        elseif slope > 4 || h > 30
            :grind
        else
            :rock
        end
        grid[i, j] = TerrainCell(h, surface)
    end

    return grid
end

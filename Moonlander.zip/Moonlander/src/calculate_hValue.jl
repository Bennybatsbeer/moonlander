#########################
##  calculate h value  ##
#########################

function calculate_hValue(i, j, dest)
    return sqrt((i - dest[1])^2 + (j - dest[2])^2)
end
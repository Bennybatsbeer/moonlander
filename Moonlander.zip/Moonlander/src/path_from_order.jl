#################################
##  make the Path local search ##
#################################

function path_from_order(order::Vector{Int}, checkpoints::Vector{Tuple{Int,Int}}, grid)
    full_path = []
    for i in 1:length(order)-1
        src, dst = checkpoints[order[i]], checkpoints[order[i+1]]
        segment = AStar(grid, src, dst)
        append!(full_path, segment[1:end-1])
    end
    push!(full_path, checkpoints[order[end]])
    return full_path
end
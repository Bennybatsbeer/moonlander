###############################
##  compute total path cost  ##
###############################

function computeTotalPathCost(grid, path)
    totalCost = 0.0
    for i in 1:length(path)-1
        (i1, j1) = path[i]
        (i2, j2) = path[i+1]
        totalCost += movementCost(grid, i1, j1, i2, j2)
    end
    return totalCost
end
########################
##  plot moonsurface  ##
########################

include("heightmap100.jl")
include("heightmap100.jl")

function plotMoonSurface(grid, path;waypoints=[])
	heightMatrix = getfield.(grid, :height)
    surfaceMatrix = getfield.(grid, :surface)
    surfaceColorMap = Dict(:dust => 1, :grind => 2, :rock => 3)
    surfaceValues = [surfaceColorMap[s] for s in surfaceMatrix]
    color_palette = [:tan, :gray, :black]
    xs = [p[2] for p in path]
    ys = [p[1] for p in path]
    wxs = [p[2] for p in waypoints]
    wys = [p[1] for p in waypoints]

	if dim == 100
    	plot(
    	    heatmap(heightMatrix, color=:terrain, aspect_ratio=1, title="Height"),
    	    heatmap(surfaceValues, color=color_palette, aspect_ratio=1, title="Surface"),
    	    layout=(1,2), size=(800, 400)
    		)
    	plot!(xs, ys, lw=2, c=:red, marker=:circle, label="", subplot=1)
    	plot!(xs, ys, lw=2, c=:red, marker=:circle, label="", subplot=2)

    	scatter!(wxs, wys, marker=(:circle, 8), c=:blue, markerstrokecolor=:yellow, label="", subplot=1)
    	scatter!(wxs, wys, marker=(:circle, 8), c=:blue, markerstrokecolor=:yellow, label="", subplot=2)
	else
    	plot(
    	    heatmap(heightMatrix, color=:terrain, aspect_ratio=1, title="Height"),
    	    heatmap(surfaceValues, color=color_palette, aspect_ratio=1, title="Surface"),
    	    layout=(1,2), size=(800, 400)
    		)
    	plot!(xs, ys, lw=2, c=:red, marker=:circle, markerstrokewidth=0, label="", subplot=1)
    	plot!(xs, ys, lw=2, c=:red, marker=:circle, markerstrokewidth=0, label="", subplot=2)

    	scatter!(wxs, wys, marker=(:circle, 8), c=:blue, markerstrokecolor=:yellow, label="", subplot=1)
    	scatter!(wxs, wys, marker=(:circle, 8), c=:blue, markerstrokecolor=:yellow, label="", subplot=2)
	end
end
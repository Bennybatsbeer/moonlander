####################
##  movementCost  ##
####################

function movementCost(grid, i, j, ni, nj)
    fromCell = grid[i, j]
    toCell = grid[ni, nj]
    return surfaceCosts[toCell.surface] + abs(toCell.height - fromCell.height)
end
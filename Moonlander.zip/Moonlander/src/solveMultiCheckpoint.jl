##########################
##  solve Christofides  ##
##########################

function solveMultiCheckpoint(grid, checkpoints)
    n = length(checkpoints)
    distMatrix = zeros(Float64, n, n)
    paths = Matrix{Vector{Tuple{Int, Int}}}(undef, n, n)

    for i in 1:n, j in i+1:n
        path = AStar(grid, checkpoints[i], checkpoints[j])
        cost = computeTotalPathCost(grid, path)
        distMatrix[i, j] = cost
        distMatrix[j, i] = cost
        paths[i, j] = path
        paths[j, i] = reverse(path)
    end

    g = SimpleWeightedGraph(n)
    for i in 1:n, j in i+1:n
        add_edge!(g, i, j, distMatrix[i, j])
    end
	p1 = gplot(g, nodelabel=["S$(i)" for i in 1:n])

    mst_edges = kruskal_mst(g)
    mst_graph = SimpleWeightedGraph(n)
    for e in mst_edges
        add_edge!(mst_graph, src(e), dst(e), weight(e))
    end
	p2 = gplot(mst_graph, nodelabel=["S$(i)" for i in 1:n])

    odd_nodes = [v for v in vertices(mst_graph) if degree(mst_graph, v) % 2 == 1]
    used = Set{Int}()
    matches = Tuple{Int, Int}[]
    for i in odd_nodes
        if i in used
            continue
        end
        mincost, partner = Inf, -1
        for j in odd_nodes
            if i == j || j in used
                continue
            end
            if distMatrix[i, j] < mincost
                mincost = distMatrix[i, j]
                partner = j
            end
        end
        if partner != -1
            push!(matches, (i, partner))
            push!(used, i, partner)
        end
    end

    multigraph = SimpleWeightedGraph(n)
    for e in mst_edges
        add_edge!(multigraph, src(e), dst(e), weight(e))
    end
    for (i, j) in matches
        add_edge!(multigraph, i, j, distMatrix[i, j])
    end
	p3 = gplot(multigraph, nodelabel=["S$(i)" for i in 1:n])
	
    tour = eulerian(multigraph)
    seen = Set{Int}()
    global tsp_order = Int[]
    for v in tour
        if !(v in seen)
            push!(seen, v)
            push!(tsp_order, v)
        end
    end
    push!(tsp_order, tsp_order[1])
    println(tsp_order)

	g_tspsol = SimpleWeightedGraph(n)

    fullPath = []
	g_tspsol = SimpleWeightedGraph(n)
    for i in 1:length(tsp_order) - 1
        u, v = tsp_order[i], tsp_order[i + 1]
        append!(fullPath, paths[u, v][1:end-1])
		add_edge!(g_tspsol, u, v, distMatrix[u, v])
    end
    push!(fullPath, checkpoints[tsp_order[end]])
	add_edge!(g_tspsol, tsp_order[end], tsp_order[1], distMatrix[tsp_order[end], tsp_order[1]])
	p4 = gplot(g_tspsol, nodelabel=["S$(i)" for i in 1:n])

    println("\nThis is the total path that should be traveled by the moon lander:")
    for point in fullPath
        print(" -> ", point)
    end
    println()
	global CostMatrix = distMatrix
    return fullPath,p1,p2,p3,p4
end
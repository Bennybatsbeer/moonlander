#################################
##  Main function Christofides ##
#################################
include("heightmap100.jl")
include("heightmap500.jl")

function main(dim)
	global ROW = dim;
	global COL = dim;
	if dim ==100
    	global grid = moonSurface_from_matrix(HEIGHTMAP_100)
		global checkpoints = [(1, 1), (45, 80), (60, 10), (95, 95), (20, 50), (40, 40), (70, 70)]
	else
		global grid = moonSurface_from_matrix(HEIGHTMAP_500)
		global checkpoints = [(1, 1), (225, 400), (300, 50), (475, 167), (100, 250), (176, 176), (350, 350)]
	end
    for (i,checkpoint) in enumerate(checkpoints)
        print("Checkpoint $i: $checkpoint\n")
    end
    path,plot1,plot2,plot3,plot4 = solveMultiCheckpoint(grid, checkpoints)
    print("\n\nPath total cost: ", computeTotalPathCost(grid, path))
	p1=plotMoonSurface(grid, path; waypoints=checkpoints)
	return p1,plot1,plot2,plot3,plot4;
end
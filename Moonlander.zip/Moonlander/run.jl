###############################
###############################
###   Run Moonlander Code   ###
###############################
###############################

#########################################
# PUT THIS ONE IN COMMENT IF NOT NEEDED #
#########################################
include("src/install_dependencies.jl")
#############################################################
include("src/Dependencies.jl")
include("src/Types.jl")
include("src/AStar.jl")
include("src/Terrain.jl")
include("src/TSPChristofides.jl")
include("src/TSPSimulatedAnnealing.jl")
include("src/Visualization.jl")
include("src/Main.jl")

p1,plot1,plot2,plot3,plot4 = main();

p1
plot1
plot2
plot3
plot4

best_tour, tour_length = runSimulatedAnnealingTSP(grid, checkpoints)
plotSimulatedAnnealingTour(grid, checkpoints, best_tour)